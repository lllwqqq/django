from django.contrib import admin

from .models import UserProfile
import xadmin

# Register your models here.

# class UserProfileAdmin(xadmin.ModelAdmin):
#     pass
#
#
# xadmin.site.register(UserProfile, UserProfileAdmin)
